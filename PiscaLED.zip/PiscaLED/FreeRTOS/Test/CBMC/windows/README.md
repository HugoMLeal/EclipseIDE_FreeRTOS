This directory contains include files used by the CBMC proofs:
* Windows.h and WinBase.h are include files used to build FreeRTOS (the parts we currently test) on Linux