This proof demonstrates the memory safety of the TaskGetTaskNumber function.
No assumption is required since the function accepts a NULL value for the task handle.

This proof is a work-in-progress.  Proof assumptions are described in
the harness.
